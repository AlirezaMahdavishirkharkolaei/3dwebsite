/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: ['"Instrument Serif"', 'serif'],
      },
      colors: {
        bg: 'hsl(0 0% 4%)',
        surface: 'hsl(0 0% 8%)',
        'text-primary': 'hsl(0 0% 96%)',
        muted: 'hsl(0 0% 53%)',
        stroke: 'hsl(0 0% 12%)',
      },
    },
  },
  plugins: [],
}
