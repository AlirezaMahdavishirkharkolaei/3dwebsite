import { motion } from 'framer-motion'

const ENTRIES = [
  { id: 1, title: 'The Art of Diamond Cutting', read: '5 min read', date: 'Apr 5, 2025' },
  { id: 2, title: 'How to Choose Your Engagement Ring', read: '7 min read', date: 'Mar 18, 2025' },
  { id: 3, title: 'Sustainability in Fine Jewelry', read: '4 min read', date: 'Mar 2, 2025' },
  { id: 4, title: 'Caring for Your Gemstones', read: '3 min read', date: 'Feb 14, 2025' },
]

export default function Journal() {
  return (
    <section className="py-24 border-t border-stroke">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Header */}
        <motion.div
          className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 gap-4"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div>
            <span className="text-xs tracking-[0.4em] text-muted uppercase font-light">Journal</span>
            <h2 className="font-serif italic text-[clamp(2rem,4vw,3.5rem)] text-text-primary mt-2 leading-tight">
              Stories &amp; Guides
            </h2>
          </div>
          <button className="text-sm tracking-[0.2em] text-muted hover:text-text-primary transition-colors font-light w-fit border-b border-stroke pb-0.5">
            View All Articles →
          </button>
        </motion.div>

        {/* Pills */}
        <div className="flex flex-col md:flex-row flex-wrap gap-3">
          {ENTRIES.map((entry, i) => (
            <motion.div
              key={entry.id}
              className="group flex items-center justify-between gap-8 px-7 py-5 rounded-full border border-stroke bg-surface hover:border-muted transition-all duration-300 cursor-pointer md:flex-1"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              whileHover={{ scale: 1.01 }}
            >
              <div className="flex items-center gap-4">
                <span className="text-xs tabular-nums text-muted font-light">0{entry.id}</span>
                <span className="h-3 w-px bg-stroke" />
                <p className="text-sm text-text-primary font-light whitespace-nowrap">{entry.title}</p>
              </div>
              <div className="flex items-center gap-4 shrink-0">
                <span className="text-xs text-muted hidden lg:inline">{entry.date}</span>
                <span className="text-xs tracking-wider text-muted px-3 py-1 rounded-full border border-stroke bg-bg">
                  {entry.read}
                </span>
                <span className="text-muted group-hover:text-text-primary transition-colors text-sm">→</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
