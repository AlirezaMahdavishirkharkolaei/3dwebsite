import { useRef, useState, useEffect } from 'react'
import { useInView } from 'framer-motion'
import { motion } from 'framer-motion'

interface StatItem {
  value: string
  label: string
  numeric: number
  suffix: string
}

const STATS: StatItem[] = [
  { value: '18+', label: 'Years of Excellence', numeric: 18, suffix: '+' },
  { value: '1500+', label: 'Jewelry Pieces Delivered', numeric: 1500, suffix: '+' },
  { value: '100%', label: 'Client Satisfaction', numeric: 100, suffix: '%' },
]

function CountUp({ target, suffix, inView }: { target: number; suffix: string; inView: boolean }) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    if (!inView) return
    let start = 0
    const duration = 1800
    const step = 16
    const increment = target / (duration / step)
    const timer = setInterval(() => {
      start += increment
      if (start >= target) {
        setCount(target)
        clearInterval(timer)
      } else {
        setCount(Math.floor(start))
      }
    }, step)
    return () => clearInterval(timer)
  }, [inView, target])

  return (
    <span>
      {count.toLocaleString()}
      {suffix}
    </span>
  )
}

export default function Stats() {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="stats" ref={ref} className="py-28 border-t border-stroke">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-xs tracking-[0.4em] text-muted uppercase font-light">Our Legacy</span>
          <h2 className="font-serif italic text-[clamp(2rem,4vw,3.5rem)] text-text-primary mt-3 leading-tight">
            Numbers that<br />
            <span className="accent-text">speak</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-0 md:divide-x md:divide-stroke">
          {STATS.map((stat, i) => (
            <motion.div
              key={i}
              className="flex flex-col items-center text-center py-8 px-6"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
            >
              <div
                className="text-[clamp(3.5rem,8vw,6rem)] font-light leading-none accent-text tabular-nums"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                <CountUp target={stat.numeric} suffix={stat.suffix} inView={inView} />
              </div>
              <p className="mt-4 text-sm text-muted font-light tracking-wider uppercase">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
