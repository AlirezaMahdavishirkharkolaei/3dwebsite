import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface LoadingScreenProps {
  onComplete: () => void
}

const WORDS = ['Luxury', 'Elegance', 'Timeless']
const DURATION = 2700

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [count, setCount] = useState(0)
  const [wordIndex, setWordIndex] = useState(0)
  const [exiting, setExiting] = useState(false)
  const startRef = useRef<number | null>(null)
  const rafRef = useRef<number>(0)

  useEffect(() => {
    const animate = (timestamp: number) => {
      if (!startRef.current) startRef.current = timestamp
      const elapsed = timestamp - startRef.current
      const progress = Math.min(elapsed / DURATION, 1)
      setCount(Math.floor(progress * 100))

      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate)
      } else {
        setCount(100)
        setTimeout(() => {
          setExiting(true)
          setTimeout(onComplete, 700)
        }, 300)
      }
    }

    rafRef.current = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(rafRef.current)
  }, [onComplete])

  useEffect(() => {
    const interval = setInterval(() => {
      setWordIndex(i => (i + 1) % WORDS.length)
    }, 900)
    return () => clearInterval(interval)
  }, [])

  return (
    <AnimatePresence>
      {!exiting && (
        <motion.div
          key="loading"
          className="fixed inset-0 z-50 flex flex-col bg-bg"
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.6, ease: [0.76, 0, 0.24, 1] }}
        >
          {/* Top label */}
          <div className="absolute top-8 left-8">
            <span className="text-sm tracking-[0.3em] text-muted font-light uppercase">FANCY</span>
          </div>

          {/* Center content */}
          <div className="flex flex-1 flex-col items-center justify-center gap-6">
            {/* Counter */}
            <div className="loading-counter text-[clamp(5rem,15vw,12rem)] font-light text-text-primary leading-none tabular-nums">
              {String(count).padStart(3, '0')}
            </div>

            {/* Rotating word */}
            <div className="h-8 overflow-hidden relative">
              <AnimatePresence mode="wait">
                <motion.p
                  key={WORDS[wordIndex]}
                  className="text-sm tracking-[0.4em] text-muted uppercase font-light"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -20, opacity: 0 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                >
                  {WORDS[wordIndex]}
                </motion.p>
              </AnimatePresence>
            </div>
          </div>

          {/* Bottom progress bar */}
          <div className="w-full px-8 pb-10">
            <div className="w-full h-px bg-stroke overflow-hidden relative">
              <motion.div
                className="absolute left-0 top-0 h-full accent-gradient accent-glow"
                style={{ width: `${count}%` }}
                transition={{ ease: 'linear' }}
              />
            </div>
            <div className="flex justify-between mt-3">
              <span className="text-xs text-muted font-light tracking-widest">LOADING</span>
              <span className="text-xs text-muted font-light tabular-nums">{count}%</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
