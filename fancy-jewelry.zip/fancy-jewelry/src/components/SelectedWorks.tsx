import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'

const WORKS = [
  {
    id: 1,
    title: 'The Elysian Ring',
    category: 'Ring',
    img: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=900&auto=format&fit=crop&q=80',
    col: 'col-span-12 md:col-span-7',
    aspect: 'aspect-[4/3] md:aspect-[3/2]',
  },
  {
    id: 2,
    title: 'Aurora Necklace',
    category: 'Necklace',
    img: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=900&auto=format&fit=crop&q=80',
    col: 'col-span-12 md:col-span-5',
    aspect: 'aspect-[4/3] md:aspect-square',
  },
  {
    id: 3,
    title: 'Cascade Bracelet',
    category: 'Bracelet',
    img: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=900&auto=format&fit=crop&q=80',
    col: 'col-span-12 md:col-span-5',
    aspect: 'aspect-[4/3] md:aspect-[4/3]',
  },
  {
    id: 4,
    title: 'Mirage Earrings',
    category: 'Earrings',
    img: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=900&auto=format&fit=crop&q=80',
    col: 'col-span-12 md:col-span-7',
    aspect: 'aspect-[4/3] md:aspect-[16/9]',
  },
]

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12 } },
}

const item = {
  hidden: { opacity: 0, y: 40 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] } },
}

export default function SelectedWorks() {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section id="work" className="py-28 px-6 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div
        className="mb-14"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <span className="text-xs tracking-[0.4em] text-muted uppercase font-light">Selected Works</span>
        <h2 className="font-serif italic text-[clamp(2.5rem,6vw,5rem)] text-text-primary mt-3 leading-tight">
          Crafted to<br />
          <span className="accent-text">endure</span>
        </h2>
      </motion.div>

      {/* Bento grid */}
      <motion.div
        ref={ref}
        className="grid grid-cols-12 gap-4"
        variants={container}
        initial="hidden"
        animate={inView ? 'show' : 'hidden'}
      >
        {WORKS.map(work => (
          <motion.div
            key={work.id}
            className={`${work.col} work-item group relative rounded-2xl overflow-hidden bg-surface cursor-pointer`}
            variants={item}
          >
            <div className={`relative ${work.aspect} w-full`}>
              <img
                src={work.img}
                alt={work.title}
                className="absolute inset-0 w-full h-full object-cover"
                loading="lazy"
              />
              {/* Overlay */}
              <div className="overlay absolute inset-0 bg-bg/60 flex flex-col items-center justify-center">
                <p className="text-text-primary text-sm tracking-[0.3em] uppercase font-light">
                  Discover —&nbsp;
                  <span className="accent-text font-medium">{work.title}</span>
                </p>
              </div>
              {/* Bottom label */}
              <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-bg/90 to-transparent">
                <span className="text-xs tracking-[0.3em] text-muted uppercase font-light">{work.category}</span>
                <p className="text-base text-text-primary font-light mt-0.5">{work.title}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </section>
  )
}
