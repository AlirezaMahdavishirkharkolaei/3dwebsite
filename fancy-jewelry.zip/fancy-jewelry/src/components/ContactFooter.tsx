import { useEffect, useRef } from 'react'
import Hls from 'hls.js'
import gsap from 'gsap'

const HLS_URL = 'https://stream.mux.com/Aa02T7oM1wH5Mk5EEVDYhbZ1ChcdhRsS2m1NYyx4Ua1g.m3u8'
const MARQUEE_TEXT = 'TIMELESS ELEGANCE • '

const SOCIALS = [
  {
    label: 'Instagram',
    href: 'https://instagram.com',
    icon: (
      <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
        <rect x="2" y="2" width="20" height="20" rx="5" />
        <circle cx="12" cy="12" r="4.5" />
        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
      </svg>
    ),
  },
  {
    label: 'Pinterest',
    href: 'https://pinterest.com',
    icon: (
      <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
        <path d="M12 2C6.477 2 2 6.477 2 12c0 4.236 2.636 7.855 6.356 9.312-.088-.791-.167-2.005.035-2.868.181-.78 1.172-4.97 1.172-4.97s-.299-.598-.299-1.482c0-1.388.806-2.428 1.808-2.428.853 0 1.267.64 1.267 1.408 0 .858-.546 2.14-.828 3.33-.236.995.499 1.806 1.476 1.806 1.771 0 3.135-1.866 3.135-4.56 0-2.383-1.714-4.048-4.16-4.048-2.832 0-4.494 2.124-4.494 4.32 0 .856.33 1.772.741 2.273a.3.3 0 01.069.286c-.076.314-.244.995-.277 1.134-.044.183-.146.222-.337.134-1.249-.581-2.03-2.407-2.03-3.874 0-3.154 2.292-6.052 6.608-6.052 3.469 0 6.165 2.473 6.165 5.776 0 3.447-2.173 6.22-5.19 6.22-1.013 0-1.966-.527-2.292-1.148l-.623 2.378c-.226.869-.835 1.958-1.244 2.621.937.29 1.931.445 2.962.445 5.523 0 10-4.477 10-10S17.523 2 12 2z" />
      </svg>
    ),
  },
  {
    label: 'Facebook',
    href: 'https://facebook.com',
    icon: (
      <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
      </svg>
    ),
  },
  {
    label: 'LinkedIn',
    href: 'https://linkedin.com',
    icon: (
      <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
        <rect x="2" y="9" width="4" height="12" />
        <circle cx="4" cy="4" r="2" />
      </svg>
    ),
  },
]

export default function ContactFooter() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const marqueeRef = useRef<HTMLDivElement>(null)

  // HLS video
  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    if (Hls.isSupported()) {
      const hls = new Hls()
      hls.loadSource(HLS_URL)
      hls.attachMedia(video)
      hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}))
      return () => hls.destroy()
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = HLS_URL
      video.play().catch(() => {})
    }
  }, [])

  // GSAP marquee
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.to(marqueeRef.current, {
        xPercent: -50,
        ease: 'none',
        duration: 16,
        repeat: -1,
      })
    })
    return () => ctx.revert()
  }, [])

  return (
    <footer className="relative overflow-hidden border-t border-stroke">
      {/* Flipped background video */}
      <div className="absolute inset-0 overflow-hidden">
        <video
          ref={videoRef}
          className="absolute inset-0 w-full h-full object-cover scale-y-[-1]"
          muted
          loop
          playsInline
          autoPlay
        />
        <div className="absolute inset-0 bg-bg/85" />
      </div>

      {/* Marquee */}
      <div className="relative overflow-hidden border-b border-stroke/50 py-5">
        <div ref={marqueeRef} className="flex whitespace-nowrap" style={{ width: 'max-content' }}>
          {Array.from({ length: 8 }).map((_, i) => (
            <span
              key={i}
              className="text-[clamp(1rem,2.5vw,1.5rem)] font-serif italic tracking-wider text-muted mr-8"
            >
              {MARQUEE_TEXT}
            </span>
          ))}
        </div>
      </div>

      {/* Main footer content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-start">
          {/* Left: Big CTA */}
          <div>
            <h2 className="font-serif italic text-[clamp(2.5rem,7vw,6rem)] leading-tight text-text-primary">
              Let's create<br />
              <span className="accent-text">something</span><br />
              beautiful
            </h2>
            <div className="mt-8 flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-sm text-muted font-light">Available for private appointments</span>
            </div>
          </div>

          {/* Right: Contact info */}
          <div className="flex flex-col justify-between gap-12">
            <div>
              <p className="text-xs tracking-[0.4em] text-muted uppercase font-light mb-4">Get in touch</p>
              <a
                href="mailto:hello@fancyjewelry.com"
                className="text-xl md:text-2xl text-text-primary font-light hover:accent-text transition-all duration-300 block"
              >
                hello@fancyjewelry.com
              </a>
            </div>

            <div>
              <p className="text-xs tracking-[0.4em] text-muted uppercase font-light mb-4">Follow Us</p>
              <div className="flex gap-4">
                {SOCIALS.map(s => (
                  <a
                    key={s.label}
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    className="w-10 h-10 rounded-full border border-stroke flex items-center justify-center text-muted hover:text-text-primary hover:border-muted transition-all duration-300"
                  >
                    {s.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-20 pt-8 border-t border-stroke flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-full bg-surface border border-stroke flex items-center justify-center">
              <span className="font-serif italic text-xs text-text-primary">F</span>
            </div>
            <span className="text-xs tracking-[0.25em] font-light text-muted uppercase">FANCY</span>
          </div>
          <p className="text-xs text-muted font-light">
            © {new Date().getFullYear()} FANCY Jewelry. All rights reserved.
          </p>
          <div className="flex gap-6">
            <button className="text-xs text-muted hover:text-text-primary transition-colors font-light">Privacy Policy</button>
            <button className="text-xs text-muted hover:text-text-primary transition-colors font-light">Terms</button>
          </div>
        </div>
      </div>
    </footer>
  )
}
