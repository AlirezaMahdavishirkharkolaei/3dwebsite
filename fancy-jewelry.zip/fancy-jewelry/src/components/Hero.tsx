import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Hls from 'hls.js'
import gsap from 'gsap'
import { Link } from 'react-scroll'

const ROLES = ['Designer', 'Craftsman', 'Curator']
const HLS_URL = 'https://stream.mux.com/Aa02T7oM1wH5Mk5EEVDYhbZ1ChcdhRsS2m1NYyx4Ua1g.m3u8'

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const heroRef = useRef<HTMLDivElement>(null)
  const headingRef = useRef<HTMLHeadingElement>(null)
  const subtitleRef = useRef<HTMLDivElement>(null)
  const descRef = useRef<HTMLParagraphElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)
  const [roleIndex, setRoleIndex] = useState(0)

  // HLS video setup
  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    if (Hls.isSupported()) {
      const hls = new Hls({ autoStartLoad: true })
      hls.loadSource(HLS_URL)
      hls.attachMedia(video)
      hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}))
      return () => hls.destroy()
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = HLS_URL
      video.play().catch(() => {})
    }
  }, [])

  // Rotating roles
  useEffect(() => {
    const t = setInterval(() => setRoleIndex(i => (i + 1) % ROLES.length), 2500)
    return () => clearInterval(t)
  }, [])

  // GSAP entrance
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ delay: 0.2 })
      tl.fromTo(
        headingRef.current,
        { opacity: 0, y: 60, filter: 'blur(12px)' },
        { opacity: 1, y: 0, filter: 'blur(0px)', duration: 1.1, ease: 'power3.out' }
      )
        .fromTo(
          subtitleRef.current,
          { opacity: 0, y: 30, filter: 'blur(8px)' },
          { opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.9, ease: 'power3.out' },
          '-=0.6'
        )
        .fromTo(
          descRef.current,
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out' },
          '-=0.5'
        )
        .fromTo(
          ctaRef.current,
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.7, ease: 'power2.out' },
          '-=0.4'
        )
    }, heroRef)
    return () => ctx.revert()
  }, [])

  return (
    <section id="hero" ref={heroRef} className="relative w-full h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background video */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover"
        muted
        loop
        playsInline
        autoPlay
      />

      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-bg/70 via-bg/50 to-bg/80 z-10" />

      {/* Content */}
      <div className="relative z-20 text-center px-6 max-w-5xl mx-auto w-full">
        {/* Main heading */}
        <h1
          ref={headingRef}
          className="font-serif italic text-[clamp(5rem,18vw,14rem)] leading-none text-text-primary opacity-0 tracking-tight"
        >
          FANCY
        </h1>

        {/* Rotating role */}
        <div ref={subtitleRef} className="mt-4 h-8 flex items-center justify-center opacity-0">
          <AnimatePresence mode="wait">
            <motion.span
              key={ROLES[roleIndex]}
              className="text-sm tracking-[0.5em] text-muted uppercase font-light"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.4 }}
            >
              {ROLES[roleIndex]}
            </motion.span>
          </AnimatePresence>
        </div>

        {/* Description */}
        <p ref={descRef} className="mt-8 text-base text-muted font-light leading-relaxed max-w-lg mx-auto opacity-0">
          Each piece tells a story of elegance and precision. Discover the art of fine jewelry, crafted for moments that last forever.
        </p>

        {/* CTAs */}
        <div ref={ctaRef} className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 opacity-0">
          <Link to="work" smooth duration={800}>
            <button className="px-8 py-3 rounded-full accent-gradient text-bg text-sm font-medium tracking-widest uppercase transition-all duration-300 hover:opacity-90 hover:scale-105">
              Explore Collection
            </button>
          </Link>
          <button className="px-8 py-3 rounded-full border border-stroke text-text-primary text-sm font-light tracking-widest uppercase hover:border-muted transition-all duration-300">
            Book Consultation
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2">
        <span className="text-xs tracking-[0.3em] text-muted uppercase font-light">Scroll</span>
        <div className="scroll-indicator w-px h-8 bg-gradient-to-b from-muted to-transparent" />
      </div>
    </section>
  )
}
