import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const IMAGES = [
  {
    id: 1,
    src: 'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=700&auto=format&fit=crop&q=80',
    alt: 'Gold anklet',
    col: 0,
  },
  {
    id: 2,
    src: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=700&auto=format&fit=crop&q=80',
    alt: 'Jewelry set',
    col: 1,
  },
  {
    id: 3,
    src: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=700&auto=format&fit=crop&q=80',
    alt: 'Diamond ring',
    col: 0,
  },
  {
    id: 4,
    src: 'https://images.unsplash.com/photo-1601121141418-a38e8f9c15fd?w=700&auto=format&fit=crop&q=80',
    alt: 'Ruby ring',
    col: 1,
  },
  {
    id: 5,
    src: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=700&auto=format&fit=crop&q=80',
    alt: 'Delicate necklace',
    col: 0,
  },
  {
    id: 6,
    src: 'https://images.unsplash.com/photo-1573408301185-9519f94b4ed8?w=700&auto=format&fit=crop&q=80',
    alt: 'Women bracelet',
    col: 1,
  },
]

export default function Explorations() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const pinRef = useRef<HTMLDivElement>(null)
  const col0Ref = useRef<HTMLDivElement>(null)
  const col1Ref = useRef<HTMLDivElement>(null)
  const [lightbox, setLightbox] = useState<{ src: string; alt: string } | null>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Pin the section for parallax scrolling
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top top',
        end: '+=200%',
        pin: pinRef.current,
        pinSpacing: true,
      })

      // Column 0 scrolls up faster
      gsap.to(col0Ref.current, {
        yPercent: -30,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=200%',
          scrub: 1,
        },
      })

      // Column 1 scrolls up slower
      gsap.to(col1Ref.current, {
        yPercent: -12,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=200%',
          scrub: 1,
        },
      })
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  const col0Images = IMAGES.filter(img => img.col === 0)
  const col1Images = IMAGES.filter(img => img.col === 1)

  return (
    <>
      <section ref={sectionRef} className="relative" style={{ height: '300vh' }}>
        <div ref={pinRef} className="w-full h-screen overflow-hidden flex flex-col">
          {/* Header */}
          <div className="px-6 lg:px-10 pt-20 pb-8 max-w-7xl mx-auto w-full">
            <span className="text-xs tracking-[0.4em] text-muted uppercase font-light">Explorations</span>
            <h2 className="font-serif italic text-[clamp(2rem,4vw,3.5rem)] text-text-primary mt-2 leading-tight">
              Craftsmanship<br />
              <span className="accent-text">up close</span>
            </h2>
          </div>

          {/* Two-column parallax gallery */}
          <div className="flex-1 overflow-hidden px-6 lg:px-10 pb-6 max-w-7xl mx-auto w-full">
            <div className="grid grid-cols-2 gap-4 h-full">
              {/* Column 0 */}
              <div ref={col0Ref} className="flex flex-col gap-4">
                {col0Images.map(img => (
                  <div
                    key={img.id}
                    className="relative rounded-2xl overflow-hidden cursor-zoom-in group"
                    style={{ aspectRatio: '3/4' }}
                    onClick={() => setLightbox({ src: img.src, alt: img.alt })}
                  >
                    <img
                      src={img.src}
                      alt={img.alt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-bg/0 group-hover:bg-bg/30 transition-all duration-300 flex items-center justify-center">
                      <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-xs tracking-widest text-text-primary uppercase border border-white/30 px-4 py-2 rounded-full backdrop-blur-sm">
                        View
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Column 1 (offset start) */}
              <div ref={col1Ref} className="flex flex-col gap-4 mt-16">
                {col1Images.map(img => (
                  <div
                    key={img.id}
                    className="relative rounded-2xl overflow-hidden cursor-zoom-in group"
                    style={{ aspectRatio: '3/4' }}
                    onClick={() => setLightbox({ src: img.src, alt: img.alt })}
                  >
                    <img
                      src={img.src}
                      alt={img.alt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-bg/0 group-hover:bg-bg/30 transition-all duration-300 flex items-center justify-center">
                      <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-xs tracking-widest text-text-primary uppercase border border-white/30 px-4 py-2 rounded-full backdrop-blur-sm">
                        View
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center lightbox-backdrop bg-bg/90"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightbox(null)}
          >
            <motion.img
              src={lightbox.src}
              alt={lightbox.alt}
              className="max-w-[90vw] max-h-[85vh] rounded-2xl object-contain"
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              transition={{ duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
              onClick={e => e.stopPropagation()}
            />
            <button
              className="absolute top-6 right-6 text-muted hover:text-text-primary transition-colors text-2xl font-light"
              onClick={() => setLightbox(null)}
            >
              ✕
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
