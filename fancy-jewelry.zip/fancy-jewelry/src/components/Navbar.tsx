import { useEffect, useState } from 'react'
import { Link } from 'react-scroll'
import { motion } from 'framer-motion'

const navLinks = [
  { label: 'Home', to: 'hero' },
  { label: 'Collections', to: 'work' },
  { label: 'Story', to: 'stats' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
        scrolled ? 'bg-bg/80 backdrop-blur-md border-b border-stroke' : 'bg-transparent'
      }`}
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, delay: 0.1, ease: [0.76, 0, 0.24, 1] }}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="logo-ring relative w-9 h-9 rounded-full bg-surface flex items-center justify-center">
            <span className="font-serif italic text-lg text-text-primary z-10">F</span>
          </div>
          <span className="text-sm tracking-[0.25em] font-light text-text-primary uppercase">FANCY</span>
        </div>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              smooth
              duration={800}
              className="text-sm text-muted hover:text-text-primary transition-colors cursor-pointer tracking-wide font-light"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Inquire button */}
        <div className="hidden md:block">
          <button className="group relative text-sm font-light tracking-widest px-5 py-2 rounded-full border border-stroke text-text-primary hover:border-transparent transition-all duration-300 overflow-hidden">
            <span className="relative z-10">Inquire</span>
            <span className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{ background: 'linear-gradient(90deg, rgba(137,170,204,0.15) 0%, rgba(78,133,191,0.15) 100%)', border: '1px solid transparent', backgroundClip: 'padding-box' }}>
            </span>
            <span className="pointer-events-none absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{ padding: '1px', background: 'linear-gradient(90deg, #89AACC, #4E85BF)', WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)', WebkitMaskComposite: 'xor', maskComposite: 'exclude' }}>
            </span>
          </button>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMenuOpen(v => !v)}
          aria-label="Toggle menu"
        >
          <span className={`block w-5 h-px bg-text-primary transition-all duration-300 ${menuOpen ? 'rotate-45 translate-y-[9px]' : ''}`} />
          <span className={`block w-5 h-px bg-text-primary transition-all duration-300 ${menuOpen ? 'opacity-0' : ''}`} />
          <span className={`block w-5 h-px bg-text-primary transition-all duration-300 ${menuOpen ? '-rotate-45 -translate-y-[9px]' : ''}`} />
        </button>
      </div>

      {/* Mobile menu */}
      <motion.div
        className="md:hidden overflow-hidden"
        initial={false}
        animate={{ height: menuOpen ? 'auto' : 0 }}
        transition={{ duration: 0.35, ease: [0.76, 0, 0.24, 1] }}
      >
        <div className="px-6 pb-6 pt-2 flex flex-col gap-5 border-t border-stroke bg-bg/95 backdrop-blur-md">
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              smooth
              duration={800}
              className="text-base text-muted hover:text-text-primary transition-colors cursor-pointer tracking-wide font-light"
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <button className="mt-2 text-sm font-light tracking-widest px-5 py-2.5 rounded-full border border-stroke text-text-primary w-fit">
            Inquire
          </button>
        </div>
      </motion.div>
    </motion.header>
  )
}
